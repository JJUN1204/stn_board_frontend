import React from "react";

function Chart() {
  return (
    <div className="App">
      <h1>테스트입니다.</h1>
    </div>
  );
}

export default Chart;